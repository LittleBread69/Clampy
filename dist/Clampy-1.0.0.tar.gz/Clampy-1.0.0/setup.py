from setuptools import setup, find_packages

setup(
    name="Clampy",
    version="1.0.0",
    packages=find_packages(),
    author="LittleBread69",
    author_email="chelouminatis+pypi@gmail.com",
    description="Clamp your vars",
    url="https://github.com/LittleBread69/Clampy",
    license="MIT",
)