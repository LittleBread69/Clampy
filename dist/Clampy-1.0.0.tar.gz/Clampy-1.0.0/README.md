# Clampy

Clampy is a small package written in Python3 to clamp values.
